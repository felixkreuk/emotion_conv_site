#!/usr/bin/env python

from pathlib import Path
import hashlib

from fb_sweep import sweep
from fb_sweep.sweep import hyperparam


PREDIFINED_GRID_FUNCTION = {}


def register_grid(name):
    def register_grid_func(fn):
        if name not in PREDIFINED_GRID_FUNCTION:
            PREDIFINED_GRID_FUNCTION[name] = fn
        return fn

    return register_grid_func


def get_predefined_grid(name):
    if name not in PREDIFINED_GRID_FUNCTION:
        return []
    else:
        return PREDIFINED_GRID_FUNCTION[name]()


def confirm(x):
    answer = ""
    while answer not in ["y", "n"]:
        answer = input(f"{x}, are you sure? [Y/N] ").lower()
    if answer != "y":
        import sys
        sys.exit(-1)


def get_grid(args):
    grid = []

    clip_norm = [0]
    wd = [0.01]

    if args.local:
        print(f"==> RUNNING IN LOCAL MODE")
        args.checkpoints_dir += "-delete"

    if "autoencode" in args.data:
        print(f"==> ADDING AUTOENCODING LANGS")
        args.langs += ",neutral-neutral,amused-amused,angry-angry,sleepy-sleepy,disgusted-disgusted"

    grid += [
        hyperparam("--arch", args.arch, save_dir_key=lambda val: f"{val}"),
        hyperparam("--task", "multilingual_translation"),
        hyperparam('--criterion', "label_smoothed_cross_entropy"),
        hyperparam('--label-smoothing', args.label_smoothing, save_dir_key=lambda val: f"ls{val}"),

        hyperparam("--lang-pairs", args.langs),
        #  hyperparam("--sampling-method", "temperature"),
        #  hyperparam("--sampling-temperature", args.sampling_temperature, save_dir_key=lambda val: f"samptmp{val}"),

        hyperparam("--optimizer", "adam", save_dir_key=lambda val: val),
        hyperparam("--adam-betas", "(0.9, 0.98)", save_dir_key=lambda val: "beta9999"),
        hyperparam("--adam-eps", 1e-6, save_dir_key=lambda val: f"eps{val}"),
        hyperparam("--lr", args.lr, save_dir_key=lambda val: f"lr{val}"),
        hyperparam("--clip-norm", clip_norm, save_dir_key=lambda val: f"clip{val}"),
        hyperparam("--dropout", args.dropout, save_dir_key=lambda val: f"drop{val}"),
        hyperparam("--attention-dropout", args.attention_dropout, save_dir_key=lambda val: f"atdrop{val}"),
        hyperparam("--weight-decay", wd, save_dir_key=lambda val: f"wd{val}"),

        hyperparam("--warmup-updates", args.warmup_updates, save_dir_key=lambda val: f"warmup{val}"),
        hyperparam("--lr-scheduler", "inverse_sqrt"),

        hyperparam("--max-tokens", args.max_tokens if not args.local else 1024, save_dir_key=lambda val: f"mt{val}"),
        hyperparam("--update-freq", args.update_freq, save_dir_key=lambda val: f"uf{val}"),
        hyperparam("--max-update", args.max_update, save_dir_key=lambda val: f"mu{val}"),
        hyperparam("--required-batch-size-multiple", 8),

        hyperparam("--fp16", save_dir_key=lambda val: "fp16"),
        hyperparam("--num-workers", 4),
        hyperparam("--seed", [2], save_dir_key=lambda val: f"s{val}"),
        hyperparam("--log-format", "json"),
        hyperparam("--log-interval", 25 if not args.local else 1),

        hyperparam("--save-interval-updates", args.save_interval_updates),
        hyperparam("--no-epoch-checkpoints"),
        hyperparam("--keep-best-checkpoints", 1),
        hyperparam("--keep-interval-updates", 1),
        hyperparam("--user-dir", "/private/home/username/workspace/fairseq-py-emotion-converion/examples/emotion_conversion/fairseq_models"),
    ]

    # TOKENS
    if args.encoder_langtok:
        grid += [hyperparam("--encoder-langtok", args.encoder_langtok, save_dir_key=lambda val: f"enctok{val}")]
    if args.decoder_langtok:
        grid += [hyperparam("--decoder-langtok", save_dir_key=lambda val: f"dectok")]
    if args.share_encoders:
        grid += [hyperparam("--share-encoders", save_dir_key=lambda val: f"shrenc")]
    if args.share_decoders:
        grid += [hyperparam("--share-decoders", save_dir_key=lambda val: f"shrdec")]

    if args.mbart_hp:
        grid += [
            hyperparam("--layernorm-embedding"),
            hyperparam("--encoder-learned-pos"),
            hyperparam("--decoder-learned-pos"),
            hyperparam("--encoder-normalize-before"),
            hyperparam("--decoder-normalize-before"),
            hyperparam("--share-all-embeddings"),
            hyperparam("--share-decoder-input-output-embed", save_dir_key=lambda val: "mbarthp"),
        ]

    # FINETUNING FROM CHECKPOINT
    if args.finetune_from_model:
        x = hashlib.sha256(str(args.finetune_from_model).encode('utf-8')).hexdigest()[:5]
        try:
            import torch
            ckpt = torch.load(args.finetune_from_model)
            epoch = ckpt['extra_state']['train_iterator']['epoch']
            steps = ckpt['optimizer_history'][0]['num_updates']
            x += f".e{epoch}s{steps}"
        except: pass
        grid += [hyperparam("--finetune-from-model", args.finetune_from_model, save_dir_key=lambda val: f"finetuned{x}")]
    else:
        grid += [hyperparam("--reset-dataloader"), hyperparam("--reset-optimizer"), hyperparam("--reset-meters")]

    if args.local:
        grid += [hyperparam("--log-format", "json"), hyperparam("--log-interval", 1)]

    if not args.no_wandb:
        grid += [hyperparam("--wandb-project", "emotion")]

    return grid


def add_extra_options_func(parser):
    parser.add_argument("--arch", required=True)
    parser.add_argument("--max-tokens", default=4*1024)
    parser.add_argument("--max-update", help="max update", default=100000)
    parser.add_argument("--warmup-updates", default=2000)
    parser.add_argument("--lr", default=1e-5)
    parser.add_argument("--update_freq", default=1)
    parser.add_argument("--dropout", default=0.1)
    parser.add_argument("--attention-dropout", default=0.1)
    parser.add_argument(
        "--langs",
        default="neutral-amused,neutral-sleepy,neutral-disgusted,neutral-angry,amused-sleepy,amused-disgusted,amused-neutral,amused-angry,angry-amused,angry-sleepy,angry-disgusted,angry-neutral,disgusted-amused,disgusted-sleepy,disgusted-neutral,disgusted-angry,sleepy-amused,sleepy-neutral,sleepy-disgusted,sleepy-angry",
        type=str,
        help="a list of languages comma sperated languages which can appear in lang-pairs; "
        "note that the ordering determines language token IDs",
    )
    parser.add_argument("--save-interval-updates", default=1000)
    parser.add_argument("--finetune-from-model", default=None)
    parser.add_argument("--encoder-langtok", default=None),
    parser.add_argument("--decoder-langtok", action="store_true"),
    parser.add_argument("--label-smoothing", default=0.2),
    parser.add_argument("--share-encoders", action='store_true', default=False),
    parser.add_argument("--share-decoders", action='store_true', default=False),
    parser.add_argument("--mbart-hp", action="store_true")


def postprocess_hyperparams(args, config):
    """Postprocess a given hyperparameter configuration."""
    pass

if __name__ == '__main__':
    sweep.main(get_grid, postprocess_hyperparams, add_extra_options_func=add_extra_options_func)
