#!/usr/bin/env python

from fb_sweep import sweep
from fb_sweep.sweep import hyperparam


PREDIFINED_GRID_FUNCTION = {}


def register_grid(name):
    def register_grid_func(fn):
        if name not in PREDIFINED_GRID_FUNCTION:
            PREDIFINED_GRID_FUNCTION[name] = fn
        return fn

    return register_grid_func


def get_predefined_grid(name):
    if name not in PREDIFINED_GRID_FUNCTION:
        return []
    else:
        return PREDIFINED_GRID_FUNCTION[name]()


@register_grid("mbart_base")
def get_transformer_mbart_base_grid():
    return [
        hyperparam("--arch", "mbart_base", save_dir_key=lambda val: val),
        #  hyperparam("--lang-tok-style", "mbart"),
        hyperparam("--layernorm-embedding", binary_flag=True, save_dir_key=lambda val: "lnemb"),
        hyperparam("--encoder-learned-pos"),
        hyperparam("--decoder-learned-pos"),
        hyperparam("--encoder-normalize-before"),
        hyperparam("--decoder-normalize-before"),
        hyperparam("--share-all-embeddings"),
        hyperparam("--share-decoder-input-output-embed"),
        hyperparam("--attention-dropout", 0.1, save_dir_key=lambda val: f"ATTDRP{val}"),
        hyperparam("--relu-dropout", 0.0, save_dir_key=lambda val: f"RELDRP{val}"),
        hyperparam("--warmup-updates", 2000, save_dir_key=lambda val: f"warmup{val}"),
    ]


def get_grid(args):
    grid = []

    num_data_loaders = 4
    break_mode = args.break_mode

    # Denoising params
    poisson_lambda = [3.5]
    mask_p = [0.3]
    mask_length = ["span-poisson"]
    replace_length = [1]
    rotate = [0]
    mask_random = [0.1]
    insert = [0]
    sentence_permute = [1.0]

    seeds = [2]
    valid_subsets = "valid"
    fp16 = True

    #  if args.local:
        #  grid += [hyperparam("--train-subset", "valid")]

    if args.add_lang_token_to_dict:
        grid += [hyperparam("--add-lang-token-to-dict", save_dir_key=lambda x: "lgtkntodct")]
    if args.add_lang_token:
        grid += [hyperparam("--add-lang-token", save_dir_key=lambda x: "lgtkn")]
    grid += [hyperparam("--langs", args.langs)]

    # data settings
    grid += [hyperparam("--dataset-impl", "mmap")]

    # model settings
    grid += [
        hyperparam("--arch", args.arch, save_dir_key=lambda val: val),
        hyperparam("--criterion", "cross_entropy"),
    ]

    grid += [hyperparam( "--multilang-sampling-alpha", args.multilang_sampling_alpha, save_dir_key=lambda val: f"alp{val}")]

    # Default is complete_doc
    grid += [hyperparam( "--sample-break-mode", break_mode, save_dir_key=lambda val: f"bm{val}")]

    # batch size
    grid += [
        #  hyperparam("--tokens-per-sample", 512, save_dir_key=lambda val: f"tps{val}"),
        hyperparam("--max-tokens", args.max_tokens, save_dir_key=lambda val: f"mt{val}"),
        hyperparam("--update-freq", args.update_freq, save_dir_key=lambda val: f"uf{val}"),
        hyperparam( "--max-update", args.max_update, save_dir_key=lambda val: f"mu{val}"),
        hyperparam("--required-batch-size-multiple", 8),
    ]

    if args.max_sentences is not None:
        grid += [hyperparam( "--batch-size", args.max_sentences, save_dir_key=lambda val: f"ms{val}")]

    if args.mbart_hp:
        grid += [
            hyperparam("--layernorm-embedding"),
            hyperparam("--encoder-learned-pos"),
            hyperparam("--decoder-learned-pos"),
            hyperparam("--encoder-normalize-before"),
            hyperparam("--decoder-normalize-before"),
            hyperparam("--share-all-embeddings"),
            hyperparam("--share-decoder-input-output-embed", save_dir_key=lambda val: "mbarthp"),
        ]

    # task settings
    grid += [hyperparam("--task", "multilingual_denoising")]

    # regularization
    grid += [
        hyperparam("--dropout", args.dropout, save_dir_key=lambda val: f"dr{val}"),
        hyperparam("--attention-dropout", args.attention_dropout, save_dir_key=lambda val: f"atdr{val}"),
        hyperparam("--relu-dropout", 0.0, save_dir_key=lambda val: f"actdr{val}"),
        hyperparam("--weight-decay", 0.01, save_dir_key=lambda val: f"wd{val}"),
    ]

    # optimization settings
    grid += [
        hyperparam("--optimizer", "adam", save_dir_key=lambda val: val),
        # hyperparam("--adam-betas", "(0.9, 0.98)", save_dir_key=lambda val: "beta998"),
        hyperparam("--adam-eps", 1e-6, save_dir_key=lambda val: f"eps{val}"),
        hyperparam("--clip-norm", 0.1, save_dir_key=lambda val: f"clip{val}"),
    ]

    # lr scheduler
    grid += [
        hyperparam("--lr-scheduler", "polynomial_decay"),
        hyperparam("--lr", args.lr, save_dir_key=lambda val: f"lr{val}"),
        hyperparam("--total-num-update", args.max_update),
        hyperparam( "--warmup-updates", args.warmup_updates, save_dir_key=lambda val: f"wrm{val}"),
    ]

    if fp16:
        grid += [hyperparam("--fp16", save_dir_key=lambda val: "fp16")]

    # data loading settings
    grid += [
        hyperparam("--num-workers", num_data_loaders),
        hyperparam("--valid-subset", valid_subsets),
    ]

    grid += [
        hyperparam("--save-interval-updates", 500),
        hyperparam("--keep-interval-updates", 10),
        hyperparam("--no-epoch-checkpoints"),
    ]

    grid += [
        hyperparam("--poisson-lambda", poisson_lambda, save_dir_key=lambda val: f"lam{val}"),
        hyperparam("--mask", mask_p, save_dir_key=lambda val: f"mask{val}"),
        hyperparam("--mask-length", mask_length, save_dir_key=lambda val: f"msklen{val}"),
        hyperparam("--replace-length", replace_length, save_dir_key=lambda val: f"rpllen{val}"),
        hyperparam("--rotate", rotate, save_dir_key=lambda val: f"rot{val}"),
        hyperparam("--mask-random", mask_random, save_dir_key=lambda val: f"mskrnd{val}"),
        hyperparam("--insert", insert, save_dir_key=lambda val: f"ins{val}"),
        hyperparam("--permute-sentences", sentence_permute, save_dir_key=lambda val: f"prmsen{val}",),
    ]

    # logging settings
    grid += [
        hyperparam("--skip-invalid-size-inputs-valid-test"),
        hyperparam("--log-format", "json"),
        hyperparam("--log-interval", 100),
        hyperparam("--user-dir", "/private/home/username/workspace/fairseq-py-emotion-converion/examples/emotion_conversion/fairseq_models"),
    ]

    if not args.local:
        grid += [hyperparam("--wandb-project", "emotion")]

    if args.reset_lr_scheduler:
        grid += [hyperparam("--reset-lr-scheduler")]

    if args.reset_optimizer:
        grid += [hyperparam("--reset-optimizer")]

    # random seed
    grid += [hyperparam("--seed", seeds, save_dir_key=lambda val: f"seed{val}")]

    if args.local:
        grid += [hyperparam("--log-format", "json"), hyperparam("--log-interval", 1)]

    arch_grid = get_predefined_grid(args.arch)
    arch_grid = (
        arch_grid
        if arch_grid
        else [hyperparam("--arch", args.arch, save_dir_key=lambda val: val)]
    )
    grid += arch_grid

    return grid


def add_extra_options_func(parser):
    parser.add_argument("--arch", default="mbart_base")
    parser.add_argument("--max-tokens", default=16384)
    parser.add_argument("--max-sentences", default=None)
    parser.add_argument("--max-update", help="max update", default=3000000)
    parser.add_argument("--warmup-updates", default=10000)
    parser.add_argument("--lr", default=3e-4)
    parser.add_argument("--update-freq", default=1)
    parser.add_argument("--dropout", default=0.1)
    parser.add_argument("--attention_dropout", default=0.1)
    parser.add_argument("--multilang-sampling-alpha", default=1.0)
    parser.add_argument("--break-mode", default="eos")
    parser.add_argument("--add-lang-token", action="store_true")
    parser.add_argument("--add-lang-token-to-dict", action="store_true")
    parser.add_argument(
        "--langs",
        default="neutral,amused,angry,sleepy,disgusted,libri,blizzard",
        type=str,
        help="a list of languages comma sperated languages which can appear in lang-pairs; "
        "note that the ordering determines language token IDs",
    )
    parser.add_argument("--reset-optimizer", action="store_true")
    parser.add_argument("--reset-lr-scheduler", action="store_true")
    parser.add_argument("--mbart-hp", action='store_true', default=False),


def postprocess_hyperparams(args, config):
    """Postprocess a given hyperparameter configuration."""
    if args.local:
        print(f"==> RUNNING IN LOCAL MODE")
        args.checkpoints_dir += "-delete"

if __name__ == '__main__':
    sweep.main(get_grid, postprocess_hyperparams, add_extra_options_func=add_extra_options_func)
